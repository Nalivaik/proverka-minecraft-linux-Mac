#!/bin/sh
# CheatScan TUI 1.1 — portable Linux + macOS terminal audit helper
# POSIX /bin/sh core. Optional platform-specific tools are detected at runtime.
# Use only on systems/accounts you are authorized to inspect.

set +e

APP_NAME="CheatScan TUI"
VERSION="1.2-ubuntu-fix"
BASE_DIR=${PWD:-.}
REPORT_DIR="$BASE_DIR/cheatscan_reports"

# ---------- basic compatibility helpers ----------

have() {
  command -v "$1" >/dev/null 2>&1
}

say_skip() {
  printf '[SKIP] %s\n' "$1"
}

mkdir -p "$REPORT_DIR" 2>/dev/null || {
  REPORT_DIR="${TMPDIR:-/tmp}/cheatscan_reports"
  mkdir -p "$REPORT_DIR" 2>/dev/null || exit 1
}

OS=$(uname -s 2>/dev/null)
case "$OS" in
  Linux) PLATFORM="linux" ;;
  Darwin) PLATFORM="macos" ;;
  *) PLATFORM="unknown" ;;
esac

STAMP=$(date '+%Y-%m-%d_%H-%M-%S' 2>/dev/null)
[ -n "$STAMP" ] || STAMP="scan_$$"
REPORT="$REPORT_DIR/cheatscan_${STAMP}.txt"

TMPBASE=${TMPDIR:-/tmp}
if [ ! -d "$TMPBASE" ] || [ ! -w "$TMPBASE" ]; then
  TMPBASE=/tmp
fi

BANNED_PATTERN='akrien|ares|aristois|armor[ _-]*hotswap|arbuz|atomic|autoattack|aimbot|autoclicky|bariton|bedrock[ _-]*breaker[ _-]*mode|bleachhack|calestial|celestial|celka|chunk[ _-]*copy|clean[ _-]*cut|clientcommands|clickcrystals|crystal[ _-]*optimizer|camerautils|chest|cutthrough|dauntiblyat|deadcode|delta|diamond[ _-]*sim|doomsday|double[ _-]*hotbar|dreampool|eclipse|elytra[ _-]*swap|elytra[ _-]*hack|entity[ _-]*outliner|entity[ _-]*xray|expensive|exire|extazyy|feather[ _-]*client|forge[ _-]*hax|freecam|future|fuzeclient|hakari|hush|huzuni|hach|impact|infinity|inertia|invmove|inventory[ _-]*walk|inventory[ _-]*profiles[ _-]*next|invtweaks|inventorysorter|jex|konas|librarian[ _-]*trade[ _-]*finder|liquidbounce|lowdurabilityswitcher|luminex|meteor|minced|mobhitbox|moonhack|neverhook|nightware|nodus|nova|nurik|nursultan|nemo.?s[ _-]*inventory|nuclear|ricardo|richclient|rogalik|rusherhack|sacurachorusfind|save[ _-]*searcher|seed[ _-]*cracker|sigma|skill[ _-]*client|smart[ _-]*moving|squad|step[ _-]*up|swingthroughgrass|takker|thunderhack|topkaautobuy|troxill|tweakeroo|topkaautodrop|tool[ _-]*swap|vape|vec\.dll|venus|viaforge|viabackwards|viaproxy|wurst|wildclient|winner|worlddownloader|wexside|wissend|xray|zamorozka|zeusclient|zenithclient'

BANNED_NORMALIZED='akrien|ares|aristois|armorhotswap|arbuz|atomic|autoattack|aimbot|autoclicky|bariton|bedrockbreakermode|bleachhack|calestial|celestial|celka|chunkcopy|cleancut|clientcommands|clickcrystals|crystaloptimizer|camerautils|chest|cutthrough|dauntiblyat|deadcode|delta|diamondsim|doomsday|doublehotbar|dreampool|eclipse|elytraswap|elytrahack|entityoutliner|entityxray|expensive|exire|extazyy|featherclient|forgehax|freecam|future|fuzeclient|hakari|hush|huzuni|hach|impact|infinity|inertia|invmove|inventorywalk|inventoryprofilesnext|invtweaks|inventorysorter|jex|konas|librariantradefinder|liquidbounce|lowdurabilityswitcher|luminex|meteor|minced|mobhitbox|moonhack|neverhook|nightware|nodus|nova|nurik|nursultan|nemosinventory|nuclear|ricardo|richclient|rogalik|rusherhack|sacurachorusfind|savesearcher|seedcracker|sigma|skillclient|smartmoving|squad|stepup|swingthroughgrass|takker|thunderhack|topkaautobuy|troxill|tweakeroo|topkaautodrop|toolswap|vape|vecdll|venus|viaforge|viabackwards|viaproxy|wurst|wildclient|winner|worlddownloader|wexside|wissend|xray|zamorozka|zeusclient|zenithclient'


# Text-content matching is intentionally stricter than archive filename matching.
# STRONG terms are distinctive enough to search in ordinary configs/logs.
CONTENT_STRONG_PATTERN='akrien|aristois|armor[ _.-]*hotswap|arbuz|autoattack|aimbot|autoclicky|bariton|bedrock[ _.-]*breaker[ _.-]*mode|bleachhack|calestial|celka|chunk[ _.-]*copy|clientcommands|clickcrystals|crystal[ _.-]*optimizer|camerautils|cutthrough|dauntiblyat|diamond[ _.-]*sim|double[ _.-]*hotbar|dreampool|elytra[ _.-]*swap|elytra[ _.-]*hack|entity[ _.-]*outliner|entity[ _.-]*xray|exire|extazyy|feather[ _.-]*client|forge[ _.-]*hax|freecam|fuze[ _.-]*client|huzuni|invmove|inventory[ _.-]*walk|inventory[ _.-]*profiles[ _.-]*next|invtweaks|inventorysorter|jex|konas|librarian[ _.-]*trade[ _.-]*finder|liquidbounce|lowdurabilityswitcher|luminex|minced|mobhitbox|moonhack|neverhook|nightware|nodus|nurik|nursultan|nemo.?s[ _.-]*inventory|richclient|rogalik|rusherhack|sacurachorusfind|save[ _.-]*searcher|seed[ _.-]*cracker|sigma|skill[ _.-]*client|smart[ _.-]*moving|step[ _.-]*up|swingthroughgrass|takker|thunderhack|topkaautobuy|troxill|tweakeroo|topkaautodrop|tool[ _.-]*swap|vape|vec[._-]*dll|venus|viaforge|viabackwards|viaproxy|wurst|wildclient|worlddownloader|wexside|wissend|xray|zamorozka|zeusclient|zenithclient'

# WEAK terms are real names/modules in the supplied list but are also common
# words, names or programming identifiers. They are only searched in known
# Minecraft/launcher locations and only as whole tokens.
CONTENT_WEAK_PATTERN='ares|atomic|celestial|chest|cleancut|deadcode|delta|doomsday|eclipse|expensive|future|hach|hakari|hush|impact|infinity|inertia|meteor|nova|nuclear|ricardo|squad|winner'

content_re() {
  # Portable ERE boundary: do not use GNU-only \b, \< or \>.
  printf '(^|[^[:alnum:]])(%s)([^[:alnum:]]|$)' "$1"
}

is_minecraft_related_path() {
  p=$1
  case "$p" in
    "$HOME/.minecraft"/*|\
    "$HOME/.local/share/PrismLauncher"/*|\
    "$HOME/.local/share/PolyMC"/*|\
    "$HOME/.local/share/multimc"/*|\
    "$HOME/.local/share/ModrinthApp"/*|\
    "$HOME/.local/share/modrinthapp"/*|\
    "$HOME/.config/ATLauncher"/*|\
    "$HOME/.config/GDLauncher"/*|\
    "$HOME/.config/feather"/*|\
    "$HOME/Library/Application Support/minecraft"/*|\
    "$HOME/Library/Application Support/PrismLauncher"/*|\
    "$HOME/Library/Application Support/PolyMC"/*|\
    "$HOME/Library/Application Support/MultiMC"/*|\
    "$HOME/Library/Application Support/ModrinthApp"/*|\
    "$HOME/Library/Application Support/ATLauncher"/*|\
    "$HOME/Library/Application Support/GDLauncher"/*|\
    "$HOME/Library/Application Support/Feather"/*)
      return 0
      ;;
  esac
  return 1
}

is_reference_list_file() {
  f=$1
  [ -r "$f" ] || return 1
  # Prevent the checker/manual/source code containing its own detection list
  # from reporting itself as dozens of cheat hits.
  grep -qE 'BANNED_(NORMALIZED|PATTERN)=|CONTENT_(STRONG|WEAK)_PATTERN=|PATTERN=.akrien\|ares\|aristois' "$f" 2>/dev/null
}

if [ -t 1 ]; then
  c_reset=$(printf '\033[0m')
  c_bold=$(printf '\033[1m')
  c_cyan=$(printf '\033[36m')
  c_yellow=$(printf '\033[33m')
  c_green=$(printf '\033[32m')
  c_red=$(printf '\033[31m')
  c_blue=$(printf '\033[34m')
  c_magenta=$(printf '\033[35m')
  c_dim=$(printf '\033[2m')
else
  c_reset=''
  c_bold=''
  c_cyan=''
  c_yellow=''
  c_green=''
  c_red=''
  c_blue=''
  c_magenta=''
  c_dim=''
fi

ui_title() {
  printf '%s%s╭──────────────────────────────────────────────────────────────╮%s\n' "$c_cyan" "$c_bold" "$c_reset"
  printf '%s%s│  CheatScan TUI  ·  Linux audit console                    │%s\n' "$c_cyan" "$c_bold" "$c_reset"
  printf '%s%s╰──────────────────────────────────────────────────────────────╯%s\n' "$c_cyan" "$c_bold" "$c_reset"
}

ui_progress() {
  # Compact progress marker that works in plain pipes and old terminals.
  printf '%s→%s %s\n' "$c_blue" "$c_reset" "$1"
}

ui_result_hint() {
  case "$1" in
    *'[CONTENT]'*|*'[NAME]'*) printf '%s%s%s\n' "$c_red" "$1" "$c_reset" ;;
    *'[SKIP'*|*'[MISS]'*) printf '%s%s%s\n' "$c_yellow" "$1" "$c_reset" ;;
    *'[OK]'*|*'completed'*|*'Готово'*) printf '%s%s%s\n' "$c_green" "$1" "$c_reset" ;;
    *) printf '%s\n' "$1" ;;
  esac
}

hr() {
  printf '%s\n' '------------------------------------------------------------'
}

pause_menu() {
  printf '\nНатисни Enter, щоб продовжити...'
  IFS= read -r _unused
}

clear_screen() {
  if [ -t 1 ] && [ -n "${TERM:-}" ] && have clear; then
    clear
  else
    printf '\n\n'
  fi
}

log_section() {
  printf '\n===== %s =====\n' "$1" >> "$REPORT"
}

# tee is POSIX, but keep a fallback for extremely minimal environments.
outlog() {
  if have tee; then
    tee -a "$REPORT"
  else
    cat >> "$REPORT"
  fi
}

safe_head() {
  n=$1
  if have head; then
    head -n "$n"
  else
    cat
  fi
}

safe_tail() {
  n=$1
  if have tail; then
    tail -n "$n"
  else
    cat
  fi
}

header() {
  clear_screen
  ui_title
  printf '%sВерсія:%s %-12s %sПлатформа:%s %-8s %sКористувач:%s %s\n' \
    "$c_dim" "$c_reset" "$VERSION" "$c_dim" "$c_reset" "$PLATFORM" "$c_dim" "$c_reset" "${USER:-unknown}"
  printf '%sЗвіт:%s %s\n' "$c_dim" "$c_reset" "$REPORT"
  printf '%sУвага:%s збіги — сигнали для ручної перевірки, не автоматичний доказ.\n' "$c_yellow" "$c_reset"
  printf '%s%s%s\n' "$c_cyan" '────────────────────────────────────────────────────────────────' "$c_reset"
}

# ---------- compatibility diagnostics ----------

compatibility_check() {
  printf '%sПеревірка сумісності середовища%s\n' "$c_cyan" "$c_reset"
  log_section "COMPATIBILITY"

  printf 'OS: %s (%s)\n' "$OS" "$PLATFORM" | outlog
  printf 'Shell: %s\n' "${SHELL:-unknown}" | outlog

  missing_core=""
  for cmd in uname date id find grep sed awk sort head tail basename tr cat ps ls mkdir readlink file sha256sum; do
    if have "$cmd"; then
      printf '[OK]   %s\n' "$cmd" | outlog
    else
      printf '[MISS] %s\n' "$cmd" | outlog
      missing_core="$missing_core $cmd"
    fi
  done

  printf '\nОпціональні можливості:\n' | outlog
  for cmd in gzip zgrep lsof sqlite3 gcore gdb strings ss netstat ip ifconfig \
             journalctl systemctl systemd-detect-virt loginctl crontab \
             lscpu lspci lsblk lsusb loginctl getent \
             apt dnf yum pacman apk zypper \
             sw_vers system_profiler ioreg launchctl osascript vmmap; do
    if have "$cmd"; then
      printf '[OK]   %s\n' "$cmd" | outlog
    else
      printf '[----] %s\n' "$cmd" | outlog
    fi
  done

  if [ "$PLATFORM" = "linux" ]; then
    printf '\nLinux distribution:\n' | outlog
    if [ -r /etc/os-release ]; then
      distro_name=$(sed -n 's/^NAME="\{0,1\}\([^"].*\)"\{0,1\}$/\1/p' /etc/os-release | safe_head 1)
      distro_version=$(sed -n 's/^VERSION_ID="\{0,1\}\([^"].*\)"\{0,1\}$/\1/p' /etc/os-release | safe_head 1)
      distro_id=$(sed -n 's/^ID="\{0,1\}\([^"].*\)"\{0,1\}$/\1/p' /etc/os-release | safe_head 1)
      printf '  %s %s (%s)\n' "${distro_name:-unknown}" "${distro_version:-unknown}" "${distro_id:-unknown}" | outlog
    else
      printf '  /etc/os-release unavailable\n' | outlog
    fi
    printf '  Desktop: %s | Session: %s | Wayland: %s\n' \
      "${XDG_CURRENT_DESKTOP:-unknown}" "${XDG_SESSION_TYPE:-unknown}" "${WAYLAND_DISPLAY:-no}" | outlog
  fi

  if [ -n "$missing_core" ]; then
    printf '\nПопередження: відсутні базові утиліти:%s\n' "$missing_core" | outlog
    printf 'Скрипт запустився, але окремі пункти можуть бути недоступні.\n' | outlog
  else
    printf '\nБазове POSIX-середовище придатне для роботи.\n' | outlog
  fi
}

# ---------- system ----------

system_info() {
  printf '%sСистемна інформація%s\n' "$c_cyan" "$c_reset"
  log_section "SYSTEM INFO"

  {
    echo "Date: $(date 2>/dev/null)"
    echo "User: $(id -un 2>/dev/null)"
    if have hostname; then
      echo "Host: $(hostname 2>/dev/null)"
    else
      echo "Host: $(uname -n 2>/dev/null)"
    fi
    echo "Kernel: $(uname -a 2>/dev/null)"

    if [ "$PLATFORM" = "linux" ]; then
      if [ -r /etc/os-release ]; then
        cat /etc/os-release
      else
        for f in /etc/*release; do
          [ -r "$f" ] && cat "$f"
        done
      fi

      echo "--- CPU ---"
      if have lscpu; then
        lscpu 2>/dev/null | grep -E 'Model name|Vendor ID|Architecture'
      elif [ -r /proc/cpuinfo ]; then
        grep -E 'model name|Hardware|Processor|vendor_id' /proc/cpuinfo 2>/dev/null | safe_head 12
      else
        say_skip "CPU details unavailable"
      fi

      echo "--- GPU ---"
      if have lspci; then
        lspci 2>/dev/null | grep -Ei 'VGA|3D|Display'
      else
        say_skip "lspci unavailable"
      fi

      echo "--- Disks ---"
      if have lsblk; then
        lsblk 2>/dev/null
      elif have df; then
        df -k 2>/dev/null
      else
        say_skip "lsblk/df unavailable"
      fi

      echo "--- Network interfaces ---"
      if have ip; then
        ip -brief link 2>/dev/null || ip link 2>/dev/null
      elif have ifconfig; then
        ifconfig -a 2>/dev/null
      else
        say_skip "ip/ifconfig unavailable"
      fi

      echo "--- Virtualization ---"
      if have systemd-detect-virt; then
        systemd-detect-virt 2>/dev/null || echo none
      elif [ -r /proc/1/cgroup ]; then
        grep -Ei 'docker|podman|lxc|container|kubepods' /proc/1/cgroup 2>/dev/null | safe_head 10
      else
        say_skip "virtualization detector unavailable"
      fi

    elif [ "$PLATFORM" = "macos" ]; then
      if have sw_vers; then
        sw_vers 2>/dev/null
      fi

      echo "--- Hardware ---"
      if have system_profiler; then
        system_profiler SPHardwareDataType 2>/dev/null | safe_head 100
      else
        say_skip "system_profiler unavailable"
      fi

      echo "--- GPU ---"
      if have system_profiler; then
        system_profiler SPDisplaysDataType 2>/dev/null | safe_head 150
      else
        say_skip "system_profiler unavailable"
      fi

      echo "--- Disks ---"
      if have df; then
        df -k 2>/dev/null
      fi

      echo "--- Network interfaces ---"
      if have ifconfig; then
        ifconfig -a 2>/dev/null
      else
        say_skip "ifconfig unavailable"
      fi
    fi
  } | outlog
}

# ---------- scan roots / file scanning ----------

emit_quick_scan_roots() {
  # Fast/default scan: locations where Minecraft clients, mods, downloads and
  # temporary payloads realistically live.  The whole HOME scan is separate.
  if [ "$PLATFORM" = "linux" ]; then
    for d in \
      "$HOME/.minecraft" \
      "$HOME/.local/share/PrismLauncher" \
      "$HOME/.local/share/PolyMC" \
      "$HOME/.local/share/multimc" \
      "$HOME/.local/share/ModrinthApp" \
      "$HOME/.local/share/modrinthapp" \
      "$HOME/.config/ATLauncher" \
      "$HOME/.config/GDLauncher" \
      "$HOME/.config/feather" \
      "$HOME/Downloads" \
      "$HOME/Desktop" \
      "$HOME/Documents"
    do
      [ -d "$d" ] && printf '%s\n' "$d"
    done
  else
    for d in \
      "$HOME/Library/Application Support/minecraft" \
      "$HOME/Library/Application Support/PrismLauncher" \
      "$HOME/Library/Application Support/PolyMC" \
      "$HOME/Library/Application Support/MultiMC" \
      "$HOME/Library/Application Support/ModrinthApp" \
      "$HOME/Library/Application Support/ATLauncher" \
      "$HOME/Library/Application Support/GDLauncher" \
      "$HOME/Library/Application Support/Feather" \
      "$HOME/Downloads" \
      "$HOME/Desktop" \
      "$HOME/Documents"
    do
      [ -d "$d" ] && printf '%s\n' "$d"
    done
  fi
}

scan_temp_archives_shallow() {
  # Fast temp check: only direct files in common temp dirs. Recursive /tmp scan
  # belongs to the explicit deep mode; scanning all /tmp can include other
  # users, old test data and huge application trees.
  for d in "${TMPDIR:-/tmp}" /tmp /var/tmp /dev/shm; do
    [ -d "$d" ] || continue
    for f in "$d"/* "$d"/.*; do
      [ -f "$f" ] || continue
      case "$f" in "$TMPBASE"/cheatscan_*|*/cheatscan_reports/*) continue ;; esac
      case "$(basename "$f" | tr '[:upper:]' '[:lower:]')" in
        *.jar|*.zip|*.tar.gz|*.rar|*.7z|*.so|*.dll|*.dylib) check_banned_candidate "$f" ;;
      esac
    done
  done
}

scan_temp_configs_shallow() {
  for d in "${TMPDIR:-/tmp}" /tmp /var/tmp /dev/shm; do
    [ -d "$d" ] || continue
    for f in "$d"/* "$d"/.*; do
      [ -f "$f" ] || continue
      case "$f" in "$TMPBASE"/cheatscan_*|*/cheatscan_reports/*) continue ;; esac
      base=$(basename "$f" | tr '[:upper:]' '[:lower:]')
      case "$base" in
        *.json|*.toml|*.cfg|*.ini|*.txt|*.log|*.properties|*.yml|*.yaml) scan_config_file "$f" ;;
      esac
    done
  done
}

emit_minecraft_roots() {
  if [ "$PLATFORM" = "linux" ]; then
    for d in \
      "$HOME/.minecraft" \
      "$HOME/.local/share/PrismLauncher" \
      "$HOME/.local/share/PolyMC" \
      "$HOME/.local/share/multimc" \
      "$HOME/.local/share/ModrinthApp" \
      "$HOME/.local/share/modrinthapp" \
      "$HOME/.config/ATLauncher" \
      "$HOME/.config/GDLauncher" \
      "$HOME/.config/feather"
    do
      [ -d "$d" ] && printf '%s\n' "$d"
    done
  else
    for d in \
      "$HOME/Library/Application Support/minecraft" \
      "$HOME/Library/Application Support/PrismLauncher" \
      "$HOME/Library/Application Support/PolyMC" \
      "$HOME/Library/Application Support/MultiMC" \
      "$HOME/Library/Application Support/ModrinthApp" \
      "$HOME/Library/Application Support/ATLauncher" \
      "$HOME/Library/Application Support/GDLauncher" \
      "$HOME/Library/Application Support/Feather"
    do
      [ -d "$d" ] && printf '%s\n' "$d"
    done
  fi
}

find_candidate_archives() {
  root=$1
  [ -d "$root" ] || return 0

  # Filter by extension inside find itself.  This avoids spawning basename/tr
  # for every browser cache, Steam file, source tree, etc.
  find "$root" -type f \( \
    -name '*.jar' -o -name '*.JAR' -o \
    -name '*.zip' -o -name '*.ZIP' -o \
    -name '*.tar.gz' -o -name '*.TAR.GZ' -o \
    -name '*.rar' -o -name '*.RAR' -o \
    -name '*.7z' -o -name '*.7Z' -o \
    -name '*.so' -o -name '*.SO' -o \
    -name '*.dll' -o -name '*.DLL' -o \
    -name '*.dylib' -o -name '*.DYLIB' \
  \) -print 2>/dev/null
}

check_banned_candidate() {
  f=$1
  base=$(basename "$f" 2>/dev/null | tr '[:upper:]' '[:lower:]')
  norm=$(printf '%s' "$base" | tr -cd 'a-z0-9')
  if printf '%s\n' "$norm" | grep -Eq "($BANNED_NORMALIZED)" 2>/dev/null; then
    size=$(file_size_bytes "$f")
    modified='unknown'
    if have stat; then
      modified=$(stat -c '%y' "$f" 2>/dev/null)
      [ -n "$modified" ] || modified=$(stat -f '%Sm' "$f" 2>/dev/null)
    fi
    hash='unavailable'
    if have sha256sum; then
      hash=$(sha256sum "$f" 2>/dev/null | awk '{print $1}')
    elif have shasum; then
      hash=$(shasum -a 256 "$f" 2>/dev/null | awk '{print $1}')
    fi
    printf '[NAME] %s | bytes=%s | modified=%s | sha256=%s\n' "$f" "$size" "$modified" "${hash:-unavailable}"
  fi
}

scan_banned_root() {
  root=$1
  [ -d "$root" ] || return 0
  find_candidate_archives "$root" |
  while IFS= read -r f; do
    check_banned_candidate "$f"
  done
}

search_banned_files() {
  printf '%sПошук підозрілих JAR/архівів/бібліотек...%s\n' "$c_cyan" "$c_reset"
  printf 'Швидкий режим: Minecraft/launcher/Downloads/Desktop/Documents/temp.\n'
  log_section "BANNED FILE NAMES"

  tmp="$TMPBASE/cheatscan_files_$$.txt"
  : > "$tmp" 2>/dev/null || return 1

  emit_quick_scan_roots |
  while IFS= read -r root; do
    printf '  -> %s\n' "$root"
    scan_banned_root "$root" >> "$tmp"
  done

  printf '  -> temp (shallow)\n'
  scan_temp_archives_shallow >> "$tmp"

  # Also check files stored directly in HOME without recursively walking HOME.
  for f in "$HOME"/* "$HOME"/.*; do
    [ -f "$f" ] || continue
    case "$f" in "$REPORT"|"$REPORT_DIR"/*) continue ;; esac
    case "$(basename "$f" | tr '[:upper:]' '[:lower:]')" in
      *.jar|*.zip|*.tar.gz|*.rar|*.7z|*.so|*.dll|*.dylib) check_banned_candidate "$f" >> "$tmp" ;;
    esac
  done

  if [ -s "$tmp" ]; then
    sort -u "$tmp" 2>/dev/null | outlog
    count=$(sort -u "$tmp" 2>/dev/null | wc -l | tr -d ' ')
    printf 'Знайдено збігів: %s\n' "${count:-0}" | outlog
  else
    printf 'Збігів за назвами не знайдено.\n' | outlog
  fi
  rm -f "$tmp" 2>/dev/null
  printf 'Пункт 3 завершено.\n'
}

find_candidate_configs() {
  root=$1
  [ -d "$root" ] || return 0

  # Dependency/vendor/cache trees create enormous noise and are not runtime
  # Minecraft config locations. -prune is supported by GNU, BSD/macOS and BusyBox find.
  find "$root" \
    \( -type d \( \
      -name node_modules -o -name .git -o -name .gradle -o \
      -name .cache -o -name __pycache__ -o -name target -o \
      -name dist -o -name build \
    \) -prune \) -o \
    \( -type f -mtime -14 \( \
      -name '*.json' -o -name '*.JSON' -o \
      -name '*.toml' -o -name '*.TOML' -o \
      -name '*.cfg' -o -name '*.CFG' -o \
      -name '*.ini' -o -name '*.INI' -o \
      -name '*.txt' -o -name '*.TXT' -o \
      -name '*.log' -o -name '*.LOG' -o \
      -name '*.properties' -o -name '*.PROPERTIES' -o \
      -name '*.yml' -o -name '*.YML' -o \
      -name '*.yaml' -o -name '*.YAML' \
    \) -print \) 2>/dev/null
}
file_size_bytes() {
  f=$1
  if have stat; then
    n=$(stat -c '%s' "$f" 2>/dev/null)
    case "$n" in ''|*[!0-9]*) n=$(stat -f '%z' "$f" 2>/dev/null) ;; esac
    case "$n" in ''|*[!0-9]*) n=0 ;; esac
    printf '%s\n' "$n"
  else
    printf '0\n'
  fi
}

scan_config_file() {
  f=$1
  case "$f" in
    "$REPORT"|"$REPORT_DIR"/*|*/cheatscan_reports/*|"$TMPBASE"/cheatscan_*) return 0 ;;
    */node_modules/*|*/.git/*|*/.gradle/*|*/.cache/*|*/__pycache__/*|*/target/*|*/dist/*|*/build/*) return 0 ;;
  esac

  # A multi-gigabyte log/config can freeze grep.
  size=$(file_size_bytes "$f")
  if [ "$size" -gt 33554432 ] 2>/dev/null; then
    printf '[SKIP >32MiB] %s\n' "$f"
    return 0
  fi

  # Manuals/checker source files contain the entire blacklist by design.
  if is_reference_list_file "$f"; then
    return 0
  fi

  strong_re=$(content_re "$CONTENT_STRONG_PATTERN")
  weak_re=$(content_re "$CONTENT_WEAK_PATTERN")

  # Filename: whole-token matching only; no "ares" inside "compares".
  base=$(basename "$f" 2>/dev/null)
  name_hit=0
  if printf '%s\n' "$base" | grep -Eiq "$strong_re" 2>/dev/null; then
    name_hit=1
  elif is_minecraft_related_path "$f" && printf '%s\n' "$base" | grep -Eiq "$weak_re" 2>/dev/null; then
    name_hit=1
  fi
  [ "$name_hit" -eq 1 ] && printf '[NAME] %s\n' "$f"

  [ -r "$f" ] || return 0

  # Strong terms are searched everywhere in quick roots.
  if grep -qiE "$strong_re" "$f" 2>/dev/null; then
    printf '[CONTENT] %s\n' "$f"
    grep -inE "$strong_re" "$f" 2>/dev/null | safe_head 5 | sed 's/^/    /'
    return 0
  fi

  # Ambiguous/common terms only count inside actual Minecraft/launcher trees.
  if is_minecraft_related_path "$f" && grep -qiE "$weak_re" "$f" 2>/dev/null; then
    printf '[CONTENT-WEAK/MC] %s\n' "$f"
    grep -inE "$weak_re" "$f" 2>/dev/null | safe_head 5 | sed 's/^/    /'
  fi
}
scan_config_root() {
  root=$1
  [ -d "$root" ] || return 0
  find_candidate_configs "$root" |
  while IFS= read -r f; do
    scan_config_file "$f"
  done
}

search_configs() {
  printf '%sПошук конфігів і текстових слідів за 14 днів...%s\n' "$c_cyan" "$c_reset"
  printf 'Швидкий режим: точні токени, без node_modules/.git/build/cache.\n'
  printf 'Загальні назви (delta/future/meteor тощо) враховуються лише у Minecraft-шляхах.\n'
  log_section "CONFIG/TEXT HITS (14 DAYS)"

  tmp="$TMPBASE/cheatscan_configs_$$.txt"
  : > "$tmp" 2>/dev/null || return 1

  emit_quick_scan_roots |
  while IFS= read -r root; do
    printf '  -> %s\n' "$root"
    scan_config_root "$root" >> "$tmp"
  done
  printf '  -> temp (shallow)\n'
  scan_temp_configs_shallow >> "$tmp"

  if [ -s "$tmp" ]; then
    cat "$tmp" | outlog
  else
    printf 'Збігів у конфігах/текстових файлах не знайдено.\n' | outlog
  fi
  rm -f "$tmp" 2>/dev/null
  printf 'Пункт 4 завершено.\n'
}

# ---------- Minecraft locations ----------

minecraft_locations() {
  printf '%sMinecraft / launcher locations%s\n' "$c_cyan" "$c_reset"
  log_section "MINECRAFT LOCATIONS"

  roots_tmp="$TMPBASE/cheatscan_mcroots_$$.txt"
  emit_minecraft_roots > "$roots_tmp"

  if [ -s "$roots_tmp" ]; then
    cat "$roots_tmp" | outlog
  else
    printf 'Відомих Minecraft/launcher каталогів не знайдено.\n' | outlog
  fi

  printf '\nmods/config/versions у відомих launcher-каталогах:\n' | outlog
  while IFS= read -r root; do
    find "$root" -type d \( -name mods -o -name config -o -name versions \) -print 2>/dev/null
  done < "$roots_tmp" | safe_head 500 | outlog

  rm -f "$roots_tmp" 2>/dev/null
  printf 'Пункт 5 завершено.\n'
}

list_jars_directly_in_dir() {
  d=$1
  [ -d "$d" ] || return 0
  for f in "$d"/*.jar "$d"/*.JAR; do
    [ -f "$f" ] && printf '%s\n' "$f"
  done
}

active_mods() {
  printf '%sАктивні/встановлені mods-папки%s\n' "$c_cyan" "$c_reset"
  log_section "ACTIVE MODS"

  roots_tmp="$TMPBASE/cheatscan_mcroots_$$.txt"
  emit_minecraft_roots > "$roots_tmp"

  while IFS= read -r root; do
    find "$root" -type d -name mods -print 2>/dev/null
  done < "$roots_tmp" | safe_head 500 |
  while IFS= read -r d; do
    echo "===== $d ====="
    list_jars_directly_in_dir "$d"
  done | outlog

  rm -f "$roots_tmp" 2>/dev/null
  printf 'Пункт 6 завершено.\n'
}

# ---------- explicit deep scan ----------

deep_scan_home() {
  printf '%sГлибокий scan усього HOME%s\n' "$c_yellow" "$c_reset"
  printf 'Цей режим НАВМИСНО може працювати довго на великих HOME.\n'
  printf 'На екрані буде видно поточну фазу, тому це не виглядатиме як зависання.\n'
  log_section "DEEP HOME SCAN"

  tmp="$TMPBASE/cheatscan_deep_$$.txt"
  : > "$tmp" 2>/dev/null || return 1

  printf '[1/2] Архіви/JAR/бібліотеки у %s ...\n' "$HOME"
  scan_banned_root "$HOME" >> "$tmp"
  printf '[2/2] Конфіги/логи за 14 днів у %s ...\n' "$HOME"
  scan_config_root "$HOME" >> "$tmp"

  if [ -s "$tmp" ]; then
    cat "$tmp" | outlog
  else
    printf 'Збігів у глибокому скануванні не знайдено.\n' | outlog
  fi
  rm -f "$tmp" 2>/dev/null
  printf 'Глибоке сканування завершено.\n'
}

# ---------- Minecraft logs / accounts ----------

scan_user_logs_dir() {
  d=$1
  [ -d "$d" ] || return 0

  find "$d" -type f \( -name '*.log' -o -name '*.log.gz' \) -print 2>/dev/null |
  while IFS= read -r f; do
    case "$f" in
      *.gz)
        if have zgrep; then
          zgrep -i 'setting user:' "$f" 2>/dev/null
        elif have gzip; then
          gzip -cd "$f" 2>/dev/null | grep -i 'setting user:' 2>/dev/null
        fi
        ;;
      *)
        grep -i 'setting user:' "$f" 2>/dev/null
        ;;
    esac
  done
}

twinks_from_logs() {
  printf '%sПошук імен користувачів у Minecraft-логах%s\n' "$c_cyan" "$c_reset"
  log_section "MINECRAFT USERS FROM LOGS"

  tmp="$TMPBASE/cheatscan_twinks_$$.txt"
  : > "$tmp" 2>/dev/null || return 1

  if [ "$PLATFORM" = "macos" ]; then
    {
      scan_user_logs_dir "$HOME/Library/Application Support/minecraft"
      scan_user_logs_dir "$HOME/Library/Application Support/PrismLauncher"
      scan_user_logs_dir "$HOME/Library/Application Support/PolyMC"
      scan_user_logs_dir "$HOME/Library/Application Support/MultiMC"
      scan_user_logs_dir "$HOME/Library/Application Support/ModrinthApp"
    } | awk '{print $NF}' | sort -u > "$tmp"
  else
    {
      scan_user_logs_dir "$HOME/.minecraft"
      scan_user_logs_dir "$HOME/.local/share/PrismLauncher"
      scan_user_logs_dir "$HOME/.local/share/PolyMC"
      scan_user_logs_dir "$HOME/.local/share/multimc"
      scan_user_logs_dir "$HOME/.local/share/ModrinthApp"
      scan_user_logs_dir "$HOME/.config/ATLauncher"
      scan_user_logs_dir "$HOME/.config/GDLauncher"
      scan_user_logs_dir "$HOME/.config/feather"
    } | awk '{print $NF}' | sort -u > "$tmp"
  fi

  cat "$tmp" | outlog
  rm -f "$tmp" 2>/dev/null
}

# ---------- recent / downloads / trash ----------

recent_activity() {
  printf '%sRecent / Trash / Downloads%s\n' "$c_cyan" "$c_reset"
  log_section "RECENT / TRASH / DOWNLOADS"

  {
    if [ "$PLATFORM" = "linux" ]; then
      echo "--- GNOME recent ---"
      if [ -f "$HOME/.local/share/recently-used.xbel" ]; then
        grep -iE 'href|bookmark' "$HOME/.local/share/recently-used.xbel" 2>/dev/null | safe_tail 100
      else
        say_skip "GNOME recently-used.xbel not found"
      fi

      echo "--- KDE recent ---"
      for d in \
        "$HOME/.local/share/RecentDocuments" \
        "$HOME/.local/share/kactivitymanagerd"
      do
        [ -d "$d" ] || continue
        find "$d" -type f -print 2>/dev/null | safe_head 100
      done
      for f in \
        "$HOME/.config/kdeglobals" \
        "$HOME/.config/kactivitymanagerdrc"
      do
        [ -f "$f" ] && printf '%s\n' "$f"
      done

      echo "--- Trash ---"
      ls -la "$HOME/.local/share/Trash/files" "$HOME/.local/share/Trash/info" 2>/dev/null

      echo "--- Downloads 14d ---"
      if [ -d "$HOME/Downloads" ]; then
        find "$HOME/Downloads" -type f -mtime -14 -print 2>/dev/null | safe_tail 300
      fi

    else
      echo "--- Trash ---"
      ls -la "$HOME/.Trash" 2>/dev/null

      echo "--- Downloads 14d ---"
      if [ -d "$HOME/Downloads" ]; then
        find "$HOME/Downloads" -type f -mtime -14 -print 2>/dev/null | safe_tail 300
      fi

      echo "--- Gatekeeper quarantine DB ---"
      qdb="$HOME/Library/Preferences/com.apple.LaunchServices.QuarantineEventsV2"
      if [ -f "$qdb" ] && have sqlite3; then
        sqlite3 "$qdb" \
          'SELECT LSQuarantineTimeStamp,LSQuarantineAgentName,LSQuarantineDataURLString FROM LSQuarantineEvent ORDER BY LSQuarantineTimeStamp DESC LIMIT 100;' \
          2>/dev/null
      else
        say_skip "sqlite3 or quarantine DB unavailable"
      fi
    fi
  } | outlog
  printf 'Пункт 8 завершено.\n'
}

# ---------- browser DB locations ----------

browser_history_locations() {
  printf '%sПошук баз історії браузерів%s\n' "$c_cyan" "$c_reset"
  log_section "BROWSER HISTORY DATABASES"

  {
    if [ "$PLATFORM" = "linux" ]; then
      echo "--- Firefox ---"
      for d in \
        "$HOME/.mozilla/firefox" \
        "$HOME/snap/firefox" \
        "$HOME/.var/app/org.mozilla.firefox"
      do
        [ -d "$d" ] && find "$d" -name places.sqlite -type f -print 2>/dev/null
      done

      echo "--- Chromium family ---"
      for d in \
        "$HOME/.config/google-chrome" \
        "$HOME/.config/google-chrome-beta" \
        "$HOME/.config/chromium" \
        "$HOME/.config/BraveSoftware" \
        "$HOME/.config/vivaldi" \
        "$HOME/.config/opera" \
        "$HOME/.config/yandex-browser" \
        "$HOME/.var/app/com.google.Chrome" \
        "$HOME/.var/app/org.chromium.Chromium" \
        "$HOME/.var/app/com.brave.Browser" \
        "$HOME/.var/app/com.vivaldi.Vivaldi"
      do
        [ -d "$d" ] && find "$d" -type f -name History -print 2>/dev/null | safe_head 100
      done

    else
      echo "--- Firefox ---"
      for d in \
        "$HOME/Library/Application Support/Firefox" \
        "$HOME/Library/Application Support/firefox"
      do
        [ -d "$d" ] && find "$d" -name places.sqlite -type f -print 2>/dev/null
      done

      echo "--- Chromium family ---"
      for d in \
        "$HOME/Library/Application Support/Google/Chrome" \
        "$HOME/Library/Application Support/Chromium" \
        "$HOME/Library/Application Support/BraveSoftware" \
        "$HOME/Library/Application Support/Vivaldi" \
        "$HOME/Library/Application Support/com.operasoftware.Opera" \
        "$HOME/Library/Application Support/Yandex"
      do
        [ -d "$d" ] && find "$d" -type f -name History -print 2>/dev/null | safe_head 100
      done
    fi
  } | outlog

  printf '\nПримітка: БД лише знаходяться; програма їх не змінює.\n'
  printf 'Пункт 9 завершено.\n'
}

# ---------- processes / libraries / network ----------

java_processes() {
  printf '%sJava / Minecraft processes%s\n' "$c_cyan" "$c_reset"
  log_section "JAVA / MINECRAFT PROCESSES"

  # ps -ef is more portable than platform-specific pgrep flags.
  ps -ef 2>/dev/null | grep -Ei '[j]ava|[m]inecraft' | outlog

  printf '\nВведи PID для перегляду відкритих JAR/бібліотек (або Enter щоб пропустити): '
  IFS= read -r pid
  [ -n "$pid" ] || return 0

  case "$pid" in
    *[!0-9]*)
      echo "Невірний PID"
      return 1
      ;;
  esac

  log_section "PROCESS $pid LIBRARIES / FILES / NETWORK"

  {
    if [ "$PLATFORM" = "linux" ]; then
      if [ -r "/proc/$pid/maps" ]; then
        awk '{print $6}' "/proc/$pid/maps" 2>/dev/null |
          grep -E '\.so($|\.)|\.jar$|/tmp/|/var/tmp/|/dev/shm/' |
          sort -u
      else
        say_skip "/proc/$pid/maps unavailable"
      fi

      if have lsof; then
        echo "--- lsof ---"
        lsof -p "$pid" 2>/dev/null |
          grep -Ei '\.so|\.jar|/tmp/|/var/tmp/|/dev/shm/'
      fi

      echo "--- network ---"
      if have ss; then
        ss -tupn 2>/dev/null | grep -F "pid=$pid,"
      elif have lsof; then
        lsof -Pan -p "$pid" -i 2>/dev/null
      elif have netstat; then
        echo "PID mapping unavailable; showing general network table:"
        netstat -an 2>/dev/null | safe_head 250
      else
        say_skip "ss/lsof/netstat unavailable"
      fi

    else
      if have lsof; then
        echo "--- lsof ---"
        lsof -p "$pid" 2>/dev/null | grep -Ei '\.jar|\.dylib|\.so|/tmp/'
      else
        say_skip "lsof unavailable"
      fi

      if have vmmap; then
        echo "--- vmmap ---"
        vmmap "$pid" 2>/dev/null | grep -Ei '\.dylib|\.so|/private/tmp|/tmp'
      else
        say_skip "vmmap unavailable"
      fi

      echo "--- network ---"
      if have lsof; then
        lsof -Pan -p "$pid" -i 2>/dev/null
      elif have netstat; then
        echo "PID mapping unavailable; showing general network table:"
        netstat -an 2>/dev/null | safe_head 250
      else
        say_skip "lsof/netstat unavailable"
      fi
    fi
  } | outlog
}

# ---------- optional memory scan ----------

memory_scan() {
  printf '%sОпціональний пошук рядків у дампі памʼяті Minecraft/Java%s\n' "$c_cyan" "$c_reset"
  printf 'Потрібні права на debug/ptrace. Дамп видаляється після перевірки.\n'
  printf 'PID: '
  IFS= read -r pid

  case "$pid" in
    ''|*[!0-9]*)
      echo "Невірний PID"
      return 1
      ;;
  esac

  log_section "MEMORY STRING SCAN PID $pid"

  if [ "$PLATFORM" != "linux" ]; then
    echo "На macOS автоматичний дамп вимкнено; використай lsof/vmmap." | outlog
    return 0
  fi

  if ! have strings; then
    echo "strings не знайдено; memory scan недоступний." | outlog
    return 1
  fi

  prefix="$TMPBASE/cheatscan_dump_$$"
  dump_file=""

  if have gcore; then
    gcore -o "$prefix" "$pid" >/dev/null 2>&1
    for f in "${prefix}".* "$prefix"; do
      [ -f "$f" ] && {
        dump_file=$f
        break
      }
    done
  elif have gdb; then
    dump_file="${prefix}.core"
    gdb --batch \
      -ex "attach $pid" \
      -ex "gcore $dump_file" \
      -ex "detach" \
      -ex "quit" >/dev/null 2>&1
  else
    echo "Немає gcore/gdb; memory scan пропущено." | outlog
    return 1
  fi

  if [ -n "$dump_file" ] && [ -f "$dump_file" ]; then
    strings "$dump_file" 2>/dev/null |
      grep -iE "$BANNED_PATTERN" |
      safe_head 200 |
      outlog
    rm -f "$dump_file" "${prefix}".* "$prefix" 2>/dev/null
  else
    echo "Не вдалося створити дамп (можливі обмеження ptrace/прав)." | outlog
  fi
}

# ---------- shell history ----------

shell_history() {
  printf '%sShell history: релевантні команди%s\n' "$c_cyan" "$c_reset"
  log_section "SHELL HISTORY"

  {
    [ -r "$HOME/.bash_history" ] && cat "$HOME/.bash_history"
    [ -r "$HOME/.zsh_history" ] && cat "$HOME/.zsh_history"
    [ -r "$HOME/.local/share/fish/fish_history" ] && cat "$HOME/.local/share/fish/fish_history"
  } 2>/dev/null |
    grep -iE 'rm |mv |wget |curl |git |shred|truncate|history -c|unset HISTFILE' |
    safe_tail 150 |
    outlog

  printf '\nТакі команди самі по собі не є доказом порушення.\n'
}

# ---------- persistence ----------

list_files_one_level() {
  d=$1
  pattern=$2
  [ -d "$d" ] || return 0

  # Replaces non-portable "find -maxdepth 1".
  for f in "$d"/$pattern; do
    [ -f "$f" ] && printf '%s\n' "$f"
  done
}

persistence() {
  printf '%sАвтозапуск / persistence%s\n' "$c_cyan" "$c_reset"
  log_section "PERSISTENCE / AUTOSTART"

  {
    if [ "$PLATFORM" = "linux" ]; then
      echo "=== USER AUTOSTART ==="
      ls -la "$HOME/.config/autostart" 2>/dev/null
      for f in "$HOME"/.config/autostart/*.desktop; do
        [ -f "$f" ] || continue
        echo "--- $f ---"
        cat "$f" 2>/dev/null
      done

      echo "=== XDG AUTOSTART ==="
      ls -la /etc/xdg/autostart 2>/dev/null

      echo "=== SYSTEMD USER ENABLED ==="
      if have systemctl; then
        systemctl --user list-unit-files --state=enabled 2>/dev/null
      else
        say_skip "systemctl unavailable (non-systemd distro is OK)"
      fi

      echo "=== SYSTEMD USER TIMERS ==="
      if have systemctl; then
        systemctl --user list-timers --all 2>/dev/null
      else
        say_skip "systemctl unavailable"
      fi

      echo "=== CRON ==="
      if have crontab; then
        crontab -l 2>/dev/null
      else
        say_skip "crontab unavailable"
      fi
      ls -la /etc/cron* /var/spool/cron* 2>/dev/null

      echo "=== SHELL RC ==="
      for f in \
        "$HOME/.bashrc" \
        "$HOME/.zshrc" \
        "$HOME/.profile" \
        "$HOME/.bash_profile" \
        "$HOME/.config/fish/config.fish"
      do
        [ -r "$f" ] || continue
        echo "--- $f ---"
        grep -inE 'wget|curl|python|bash|sh |exec|nohup|LD_PRELOAD' "$f" 2>/dev/null
      done

    else
      echo "=== launchctl ==="
      if have launchctl; then
        launchctl list 2>/dev/null
      else
        say_skip "launchctl unavailable"
      fi

      echo "=== LaunchAgents / Daemons ==="
      list_files_one_level "$HOME/Library/LaunchAgents" '*.plist'
      list_files_one_level /Library/LaunchAgents '*.plist'
      list_files_one_level /Library/LaunchDaemons '*.plist'

      echo "=== Login Items ==="
      if have osascript; then
        osascript -e 'tell application "System Events" to get the name of every login item' 2>/dev/null
      else
        say_skip "osascript unavailable"
      fi
    fi
  } | outlog
}

# ---------- USB / logs ----------

usb_logs() {
  printf '%sUSB / system logs%s\n' "$c_cyan" "$c_reset"
  log_section "USB / SYSTEM LOGS"

  {
    if [ "$PLATFORM" = "linux" ]; then
      if have journalctl; then
        journalctl -k --since '14 days ago' 2>/dev/null |
          grep -iE 'usb-storage|usb |usb:|attached|disconnect' |
          safe_tail 200

        echo "--- journald lifecycle ---"
        journalctl -u systemd-journald.service --since today 2>/dev/null |
          grep -iE 'cleared|rotate|vacuum|stop|start' |
          safe_tail 100

      elif have dmesg; then
        dmesg 2>/dev/null |
          grep -iE 'usb-storage|usb |attached|disconnect' |
          safe_tail 200

      elif [ -d /sys/bus/usb/devices ]; then
        echo "No journalctl/dmesg access; current USB sysfs entries:"
        find /sys/bus/usb/devices -type f \( -name product -o -name manufacturer -o -name serial \) -print 2>/dev/null |
          safe_head 200
      else
        say_skip "journalctl/dmesg/sysfs USB info unavailable"
      fi

    else
      if have system_profiler; then
        system_profiler SPUSBDataType 2>/dev/null
      else
        say_skip "system_profiler unavailable"
      fi

      echo "--- IOUSB ---"
      if have ioreg; then
        ioreg -p IOUSB -l -w 0 2>/dev/null | safe_head 300
      else
        say_skip "ioreg unavailable"
      fi

      echo "--- 14d log ---"
      if have log; then
        log show --last 14d --style compact 2>/dev/null |
          grep -iE 'USB|IOUSB|mass storage|external disk' |
          safe_tail 200
      else
        say_skip "macOS log utility unavailable"
      fi
    fi
  } | outlog
}

# ---------- Linux-specific execution traces ----------

linux_execution_traces() {
  printf '%sLinux execution traces / loaded files%s\n' "$c_cyan" "$c_reset"
  log_section "LINUX EXECUTION TRACES"

  if [ "$PLATFORM" != "linux" ]; then
    printf 'Цей пункт доступний лише на Linux.\n' | outlog
    return 0
  fi

  {
    echo "--- Java/Minecraft command lines ---"
    ps -eo pid=,user=,lstart=,etime=,comm=,args= 2>/dev/null |
      grep -Ei '[j]ava|[j]avaw|[m]inecraft' | safe_head 200

    echo "--- Suspicious executable files in user runtime locations ---"
    for d in "$HOME/.local/bin" "$HOME/.config/autostart" "$HOME/.cache" "$HOME/.local/share" /tmp /var/tmp; do
      [ -d "$d" ] || continue
      find "$d" -type f -mtime -30 \( -perm -u+x -o -name '*.AppImage' -o -name '*.sh' -o -name '*.run' \) \
        -print 2>/dev/null | while IFS= read -r f; do
          base=$(basename "$f" | tr '[:upper:]' '[:lower:]')
          if printf '%s\n' "$base" | grep -Eq "$BANNED_PATTERN"; then
            printf '[NAME] %s\n' "$f"
          fi
        done
    done

    echo "--- Loaded kernel modules (inventory only) ---"
    if have lsmod; then
      lsmod 2>/dev/null | safe_head 200
    elif [ -r /proc/modules ]; then
      safe_head 200 < /proc/modules
    else
      say_skip "/proc/modules and lsmod unavailable"
    fi
  } | outlog
}

linux_package_history() {
  printf '%sLinux package/install history%s\n' "$c_cyan" "$c_reset"
  log_section "LINUX PACKAGE HISTORY"

  if [ "$PLATFORM" != "linux" ]; then
    printf 'Цей пункт доступний лише на Linux.\n' | outlog
    return 0
  fi

  {
    echo "--- Recent package manager logs ---"
    for f in /var/log/apt/history.log /var/log/dpkg.log /var/log/dnf.log \
             /var/log/yum.log /var/log/pacman.log /var/log/emerge.log; do
      [ -r "$f" ] || continue
      echo "### $f"
      tail -n 120 "$f" 2>/dev/null
    done
    echo "--- Installed packages matching audit terms ---"
    if have dpkg-query; then
      dpkg-query -W -f='${binary:Package}\n' 2>/dev/null | grep -Ei "$BANNED_PATTERN" | safe_head 200
    elif have rpm; then
      rpm -qa 2>/dev/null | grep -Ei "$BANNED_PATTERN" | safe_head 200
    elif have pacman; then
      pacman -Q 2>/dev/null | grep -Ei "$BANNED_PATTERN" | safe_head 200
    else
      say_skip "dpkg-query/rpm/pacman unavailable"
    fi
  } | outlog
}

# ---------- full scan / report ----------

full_scan() {
  header
  printf '%sПовне сканування (без дампу памʼяті)%s\n' "$c_green" "$c_reset"
  compatibility_check
  system_info
  search_banned_files
  search_configs
  minecraft_locations
  active_mods
  twinks_from_logs
  recent_activity
  browser_history_locations
  shell_history
  persistence
  usb_logs
  linux_execution_traces
  linux_package_history
  printf '\n%sГотово.%s Звіт: %s\n' "$c_green" "$c_reset" "$REPORT"
}

show_report() {
  if [ ! -f "$REPORT" ]; then
    echo "Звіт ще не створено."
    return 0
  fi

  lines=$(wc -l < "$REPORT" 2>/dev/null | tr -d ' ')
  [ -n "$lines" ] || lines=0

  printf '%sПовний поточний звіт (%s рядків):%s\n' "$c_cyan" "$lines" "$c_reset"
  hr
  cat "$REPORT"
  hr

  if [ "$lines" -le 3 ] 2>/dev/null; then
    printf 'У цьому запуску ще не завершено жодної перевірки, тому звіт містить лише заголовок.\n'
  fi
}

about_hits() {
  cat <<'EOF'
Як трактувати результати:

Сильний сигнал:
  • модифікація лежить в активній mods/instance;
  • вона згадується у latest.log/debug.log як реально завантажена;
  • відповідний JAR/бібліотека відкрита процесом Minecraft;
  • збігаються кілька незалежних джерел.

Слабкий сигнал:
  • одне слово/назва;
  • файл у Downloads, backup або старому архіві;
  • загальні слова на кшталт chest/future/eclipse/winner;
  • rm/curl/wget у shell history;
  • звичайний USB disconnect або restart журналу.
EOF
}

menu() {
  while :
  do
    header
    cat <<'EOF'
[1]  Перевірка сумісності команд
[2]  Інформація про систему / диски / мережу
[3]  Пошук підозрілих JAR/ZIP/SO/DLL/DYLIB
[4]  Пошук конфігів і текстових слідів за 14 днів
[5]  Minecraft / launcher папки
[6]  Активні mods-папки
[7]  Імена користувачів у Minecraft-логах
[8]  Recent / Trash / Downloads
[9]  Бази історії браузерів
[10] Java/Minecraft процеси + бібліотеки + мережа
[11] Опціональний memory strings scan
[12] Shell history
[13] Автозапуск / persistence
[14] USB / system logs
[15] Повне сканування
[16] Показати поточний звіт
[17] Як трактувати результати
[18] Глибокий scan усього HOME (може бути довгим)
[19] Linux execution traces / loaded modules
[20] Linux package/install history
[0]  Вихід
EOF
    printf '%s%s%s\n' "$c_dim" 'Красный = сигнал  |  Жёлтый = пропуск  |  Голубой = раздел' "$c_reset"
    printf '%s%s%s\n' "$c_cyan" '────────────────────────────────────────────────────────────────' "$c_reset"
    printf '%sОбери пункт:%s ' "$c_bold" "$c_reset"
    IFS= read -r choice

    case "$choice" in
      1) compatibility_check; pause_menu ;;
      2) system_info; pause_menu ;;
      3) search_banned_files; pause_menu ;;
      4) search_configs; pause_menu ;;
      5) minecraft_locations; pause_menu ;;
      6) active_mods; pause_menu ;;
      7) twinks_from_logs; pause_menu ;;
      8) recent_activity; pause_menu ;;
      9) browser_history_locations; pause_menu ;;
      10) java_processes; pause_menu ;;
      11) memory_scan; pause_menu ;;
      12) shell_history; pause_menu ;;
      13) persistence; pause_menu ;;
      14) usb_logs; pause_menu ;;
      15) full_scan; pause_menu ;;
      16) show_report; pause_menu ;;
      17) about_hits; pause_menu ;;
      18) deep_scan_home; pause_menu ;;
      19) linux_execution_traces; pause_menu ;;
      20) linux_package_history; pause_menu ;;
      0)
        printf 'Звіт: %s\n' "$REPORT"
        exit 0
        ;;
      *)
        echo "Невідомий пункт"
        ;;
    esac
  done
}

printf 'CheatScan start: %s\nPlatform: %s\nStatus: sections are appended after each completed check\n' "$(date 2>/dev/null)" "$PLATFORM" > "$REPORT"

if [ "$PLATFORM" = "unknown" ]; then
  echo "Непідтримувана ОС: $OS"
  echo "Підтримуються Linux та macOS."
  exit 1
fi

menu
